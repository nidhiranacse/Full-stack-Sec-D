const express = require("express");

const app = express();
app.use(express.json());

// In-memory store
let students = [];
let nextId = 1; // never decremented, so IDs of deleted students are not reused

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function isValidStudent({ name, email, age } = {}) {
  return (
    typeof name === "string" && name.trim().length > 0 &&
    typeof email === "string" && EMAIL_RE.test(email.trim()) &&
    Number.isInteger(age) && age > 0
  );
}

// Malformed JSON body -> 400
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && "body" in err) {
    return res.status(400).json({ error: "Invalid input" });
  }
  next(err);
});

// Create
app.post("/students", (req, res) => {
  const body = req.body || {};
  if (!isValidStudent(body)) {
    return res.status(400).json({ error: "Invalid input" });
  }
  const name = body.name.trim();
  const email = body.email.trim();
  const { age } = body;

  if (students.some((s) => s.email.toLowerCase() === email.toLowerCase())) {
    return res.status(409).json({ error: "Email already exists" });
  }

  const student = { id: nextId++, name, email, age };
  students.push(student);
  res.status(201).json(student);
});

// List (optional ?minAge=)
app.get("/students", (req, res) => {
  if (req.query.minAge !== undefined) {
    const minAge = Number(req.query.minAge);
    if (req.query.minAge === "" || Number.isNaN(minAge)) {
      return res.status(400).json({ error: "Invalid input" });
    }
    return res.status(200).json(students.filter((s) => s.age >= minAge));
  }
  res.status(200).json(students);
});

// Fetch one
app.get("/students/:id", (req, res) => {
  const student = students.find((s) => String(s.id) === req.params.id);
  if (!student) return res.status(404).json({ error: "Student not found" });
  res.status(200).json(student);
});

// Delete
app.delete("/students/:id", (req, res) => {
  const index = students.findIndex((s) => String(s.id) === req.params.id);
  if (index === -1) return res.status(404).json({ error: "Student not found" });
  students.splice(index, 1);
  res.status(204).send();
});

module.exports = app;

if (require.main === module) {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
}
